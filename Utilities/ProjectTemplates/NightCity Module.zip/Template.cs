﻿using Prism.Ioc;
using Prism.Modularity;
using Prism.Regions;
using $safeprojectname$.Views;

namespace $safeprojectname$
{
    public class $safeprojectname$ : IModule
    {
        public void OnInitialized(IContainerProvider containerProvider)
        {
            var regionManager = containerProvider.Resolve<IRegionManager>();
            regionManager.RegisterViewWithRegion("$safeprojectname$Region", typeof(Main));
        }
        public void RegisterTypes(IContainerRegistry containerRegistry)
        {

        }
    }
}
