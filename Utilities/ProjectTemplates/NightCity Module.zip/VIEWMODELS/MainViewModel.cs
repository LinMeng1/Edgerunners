﻿using Prism.Mvvm;

namespace $safeprojectname$.ViewModels
{
    public class MainViewModel : BindableBase
    {
        private string text = "$safeprojectname$.Main";
        public string Text
        {
            get => text;
            set
            {
                SetProperty(ref text, value);
            }
        }
    }
}
